import React, { useState} from 'react';
// import { useState } from 'react/cjs/react.development';
// import ExpenseItem from './components/ExpenseItem';
import Expenses from './components/Expenses';
import NewExpense from './components/NewExpense/NewExpense';


  const DUMMY_EXPENSES = [
    {
      id:'e1',
      title: 'Car Insurances',
      amount: 1500,
      date: new Date(2021, 12, 22),
    },
    {
      id:'e2',
      title: 'Bike Insurances',
      amount: 1000,
      date: new Date(2021, 2, 12),
    },
    {
      id:'e3',
      title: 'Truck Insurances',
      amount: 2500,
      date: new Date(2021, 2, 14),
    },
    {
      id:'e4',
      title: 'Bus Insurances',
      amount: 3500,
      date: new Date(2022, 12, 22),
    },
    {
      id:'e5',
      title: 'Van Insurances',
      amount: 4500,
      date: new Date(2022, 11, 21),
    },
  ];

  const App = () => {
  const [expenses, setExpenses] = useState(DUMMY_EXPENSES);

  const addExpenseHandler = expense => {
    setExpenses((prevExpenses) => {
      return[expense, ...prevExpenses];
    });
  };

  return (
    <div>
     <NewExpense onAddExpense={addExpenseHandler}/>
     <Expenses items={expenses}/> 
    </div>
  );
};

export default App;